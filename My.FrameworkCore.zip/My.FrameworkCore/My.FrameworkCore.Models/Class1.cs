﻿using System;

namespace My.FrameworkCore.Models
{
    public class Class1
    {
    }
}
