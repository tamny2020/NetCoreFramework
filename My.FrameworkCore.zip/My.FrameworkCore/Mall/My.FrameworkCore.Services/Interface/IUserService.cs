﻿using My.FrameworkCore.Models.Domain;
using System;
using System.Collections.Generic;
using System.Text;

namespace My.FrameworkCore.Services.Interface
{
    public interface IUserService : IRepository<User>
    {

    }
}
